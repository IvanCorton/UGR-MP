
#include "miniwin.h"
#include <cmath>
#include <string>
#include <iostream>
using namespace miniwin;
using namespace std;
const int RADIO = 10;

struct Punto {
    float x, y;
};

/* "Color" es un tipo enumerado definido en Miniwin.h.
Una variable de tipo Color puede tomar los siguientes valores:
NEGRO, ROJO, VERDE, AZUL, AMARILLO, MAGENTA, CYAN, BLANCO

 */

void pintaPunto(const Punto& P, Color c) {
    color(c);
    circulo_lleno(P.x, P.y, RADIO);

}

void pintaLinea(const Punto& a, const Punto& b, Color c) {
    color(c);
    linea(a.x, a.y, b.x, b.y);

}



void rotar(Punto &p, double rads, Punto origen) {
    double deltaX = p.x - origen.x;
    double deltaY = p.y - origen.y;

    p.x = origen.x + deltaX * cos(rads) - deltaY * sin(rads);
    p.y = origen.y + deltaX * sin(rads) + deltaY * cos(rads);

}

int main() {
    vredimensiona(800, 800);


    // EJEMPLO 1. 
    // ROTAR UN PUNTO ALREDEDOR DE OTRO CIERTO NUMERO DE GRADOS

    Punto centro = {300, 300};
    Punto A = {400, 400};
    Punto aux;
    double grados = 5; // rotacion de 5 grados
    double rads = grados * (M_PI / 180.0);
    int contador = 0;
    int limite = 70;
    while (tecla() != ESCAPE) {
        rotar(A, rads, centro);
        borra();
        pintaLinea(A, centro, BLANCO);
        pintaPunto(A, ROJO);
        pintaPunto(centro, VERDE);

        refresca();
        espera(50);
        contador++;
        if (contador > limite) {
            // intercambio el vertice que se queda fijo
            aux = centro;
            centro = A;
            A = aux;
            limite += rand() % 20 - 10;
            contador = 0;
        }
    }



    // EJEMPLO 2
    // se rota un triangulo alrededor de uno de sus vertices
    // cada cierto tiempo, cambia el vértice de rotacion

    /*
    Punto A = {300, 300};
    Punto B = {200, 400};
    Punto C = {400, 400};
    Punto centro = A;
    double grados = 5;
    double rads= grados * (M_PI / 180.0);
    int contador = 0;
    while (tecla() != ESCAPE) {
         rotar(A, rads, centro);
         rotar(B, rads, centro);
         rotar(C, rads, centro);
         borra();
         pintaLinea(A, B, BLANCO);
         pintaLinea(B, C, BLANCO);
         pintaLinea(A, C, BLANCO);
 
        
         pintaPunto(A, VERDE);
         pintaPunto(B, ROJO);
         pintaPunto(C, AMARILLO);

        
       refresca();
       espera(50);
       contador++;
       if(contador > 70){
           // 70 es la cant. de iteraciones en hacer una vuelta completa (360/5.0)){
           int cual = rand() % 3;
           Punto actual = A;
           if (cual == 1)
               actual = B;
           if (cual == 2)
               actual = C;
           centro = actual;
           contador = 0;
          }
         
    }
    */
    vcierra();
    return 0;
}
